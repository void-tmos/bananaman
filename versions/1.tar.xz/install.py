run("cp /tmp/bananaman/bananaman.py /py/bananaman.py")
