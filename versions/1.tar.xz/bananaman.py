print("""
Do you see banana man?
Hopping over on de white hot sand
Here he come with some for me
Freshly taken from banana tree
Banana man, me want a ton
Gimme double and a bonus one
Gimme more for all me friends
Dis banana flow will never end

Do you want a banana?
Peel it down and go, Mm-mmm mm-mmm
Do you want a banana?
Dis banana for you

Tonight we dance around de flame
Then we get to play de spirit game
Spirit names we shout out loud
Shake de thunder from de spirit cloud
All de songbirds in de tree
Chant a tune to let de spirits free
Den we see dem in de night
Spirits jumping by de firelight

Do you want a banana? (Do you want a banana?)
Peel it down and go, Mm-mmm mm-mmm
Do you want a banana? (Do you want a banana?)
Dis banana for you

Look you, you too uptight you know
You could laugh and kick it back it and go (whee)
But without a rhythm or a rhyme
You do not banana all de time
Fly away from city on de run
Try to make a little fun
Look you, come to de bungalow
African't you tell me, told you so
Don't you love de bumping of de drum?
Make you shake until de bum go numb
Let de bongo play you till you drop
Dis banana never stop (never stop, never stop)

Forget all your troubles and go with de flow
Forget about whatever you may never know
Like whether whatever you doing is whatever you should
And whether anything you do is ever anything good
And then forget about banana when it stick in your throat
And when it make you wanna bellow but you stuck in a choke
And then forget about de yellow from de beckoning man
Who make you take another one and make a mock of your plan

Bungalay, bungalow
Make up your mind and tell me no

Well it's nine o'clock and it's getting dark
And the sun is falling from the sky
I've never left so early
And you may wonder why

Tomorrow morning on de plane
No banana make you go insane
Floating back to Busytown
No banana make you want to frown

Do you want a banana? (Do you want a banana?)
Peel it down and go, Mm-mmm mm-mmm
Do you want a banana?
Dis banana for you
""")
